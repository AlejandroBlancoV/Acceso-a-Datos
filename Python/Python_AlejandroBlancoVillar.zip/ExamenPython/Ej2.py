frase=input("Introduce una frase: ")
fraseTroceada=frase.split(" ")
print("La frase tiene "+str(len(fraseTroceada))+" palabras")